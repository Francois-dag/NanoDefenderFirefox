/**
 * Platform constants for Edge.
 */
"use strict";

/**
 * The extension ID of Nano Adblocker.
 * @const {string}
 */
a.NanoAdblockerExtensionID = "EdgeExtension_23837jspenguin2017NanoAdblocker_aegazecm1370c";
