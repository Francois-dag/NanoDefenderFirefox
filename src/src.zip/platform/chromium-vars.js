/**
 * Platform constants for Chromium.
 */
"use strict";

/**
 * The extension ID of Nano Adblocker.
 * @const {string}
 */
a.NanoAdblockerExtensionID = "gabbbocakeomblphkmmnoamkioajlkfo";
