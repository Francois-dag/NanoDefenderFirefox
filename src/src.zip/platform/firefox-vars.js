/**
 * Platform constants for Firefox.
 */
"use strict";

/**
 * The extension ID of Nano Adblocker.
 * @const {string}
 */
a.NanoAdblockerExtensionID = "{acf5b849-adb0-4004-b4ff-7f5332f48567}";
